package com.tnsif.accessmodifierprogram;

public class Demo {
	public static void main(String[] args) {
		Publicdemo p=new Publicdemo ();
		System.out.println(p.a);
		
	//	System.out.println(p.name);
		
		System.out.println(p.s);
		
		System.out.println(p.u);

}
}