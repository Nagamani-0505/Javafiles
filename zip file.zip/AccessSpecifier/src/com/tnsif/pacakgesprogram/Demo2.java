package com.tnsif.pacakgesprogram;
import com.tnsif.accessmodifierprogram.Publicdemo;

public class Demo2 {
	
public static void main(String[] args) {
	Publicdemo p=new Publicdemo();
	
	System.out.println(p.a);
	
	System.out.println(p.name);
	
	System.out.println(p.s);
}
}
