package com.tnsif.pacakgesprogram;
import java.util.Scanner;

public class Scannerdemo {

	public static void main(String[] args) {
		java.util.Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your uid");
		int Usn=sc.nextInt();
		
		System.out.println("Enter your name");
		String name=sc.next();
	}
}
