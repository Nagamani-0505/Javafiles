package com.tnsif.constructorprogram;
import java.util.Scanner;

public class Constructordemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Customer name:");
		String name=sc.next();
		
		System.out.println("Enter the Customer address:");
		String address=sc.next();
		
		System.out.println("Enter the Customer id:");
		int id=sc.nextInt();
		
		Customer c=new Customer();
		
		c.setCustomername(name);
		c.setCustomeraddress(address);
		c.setCustomerid(id);
		
		System.out.println(c);
		
		boolean b=c instanceof Customer;
		
		System.out.println(b);
	}

}
