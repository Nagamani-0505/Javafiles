package com.tnsif.exceptionhandling;

public class Withoutexception {
	
	public static void main(String[] args) {
		int d=0;
		int a=55/0;
		System.out.println("hello");
	}

}
