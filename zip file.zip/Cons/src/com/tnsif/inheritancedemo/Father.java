package com.tnsif.inheritancedemo;

public class Father {
	
	int money = 5000000;
	String car="BMW";
	
	void drinking() {   // behaviour or method
		System.out.println("coffee");
	}
	
	void reading() {
		System.out.println("news paper");
	}

}
