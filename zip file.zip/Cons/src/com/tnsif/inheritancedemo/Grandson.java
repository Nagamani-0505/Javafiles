package com.tnsif.inheritancedemo;

public class Grandson extends Son {
	String mobile="VIVO";
	
	public static void main(String[] args) {
		
		Grandson g=new Grandson();
		
		System.out.println(g.car);
		System.out.println(g.money);
		System.out.println(g.cycle);
		System.out.println(g.mobile);
		
		g.drinking();
		g.reading();
		
	}
	
}
