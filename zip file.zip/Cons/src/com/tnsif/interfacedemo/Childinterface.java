package com.tnsif.interfacedemo;

public interface  Childinterface extends Interfaceone {
	
	void show();

}
