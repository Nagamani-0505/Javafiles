package com.tnsif.interfacedemo;

public interface Interfaceone {
	
	void print();

}
