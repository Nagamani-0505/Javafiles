package com.tnsif.polymorphism;

public class Parentdemo {
	int a=67;
	
	void drinikng() {
		System.out.println("coffe");
	}

}
