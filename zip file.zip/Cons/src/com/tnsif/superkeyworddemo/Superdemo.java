package com.tnsif.superkeyworddemo;

public class Superdemo {

	int a=8;
	
	void driniking() {
		System.out.println("coffe");
	}


}
