package com.tnsif.constructor;

public class demo {

}
