package dem;

public class dim { // Changed class name to demo to match constructor

    dim() {
        System.out.println("welcome");
    }

    dim(int a) {
        System.out.println("Java");
    }

    dim(int a, String b) { // Corrected 'string' to 'String'
        System.out.println("Hello");
    }

    public static void main(String[] args) { // Correct main method
        dim d1 = new dim(2);          // prints "Java"
        dim d2 = new dim();           // prints "welcome"
        dim d3 = new dim(1, "REVA");  // prints "Hello"
    }
}
